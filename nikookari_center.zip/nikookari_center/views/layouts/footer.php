<?php
$app_url = $_ENV['APP_URL'] ?? 'http://localhost';
?>
    </div>
    <footer>
        <p>تمام حقوق این سایت متعلق به مرکز نیکوکاری می‌باشد &copy; <?php echo date('Y'); ?></p>
    </footer>
</body>
</html>