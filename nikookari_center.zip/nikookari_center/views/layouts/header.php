<?php
$app_url = $_ENV['APP_URL'] ?? 'http://localhost';
?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? '???? ????????'; ?></title>
    <link rel="stylesheet" href="<?php echo $app_url; ?>/css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div id="branding">
                <h1><a href="<?php echo $app_url; ?>">???? ????????</a></h1>
            </div>
            <nav>
                <ul>
                    <li><a href="<?php echo $app_url; ?>">????</a></li>
                    <li><a href="<?php echo $app_url; ?>/about">?????? ??</a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li><a href="<?php echo $app_url; ?>/user/dashboard">??????? ??</a></li>
                        <li><a href="<?php echo $app_url; ?>/logout">????</a></li>
                    <?php elseif (isset($_SESSION['admin_id'])): ?>
                        <li><a href="<?php echo $app_url; ?>/admin/dashboard">??? ??????</a></li>
                        <li><a href="<?php echo $app_url; ?>/logout">????</a></li>
                    <?php else: ?>
                        <li><a href="<?php echo $app_url; ?>/login">????</a></li>
                        <li><a href="<?php echo $app_url; ?>/register">???????</a></li>
                        <li><a href="<?php echo $app_url; ?>/admin/login">???? ?????</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container">
        <?php
        if (isset($_SESSION['success_message'])) {
            echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
            unset($_SESSION['success_message']);
        }
        if (isset($_SESSION['error_message'])) {
            echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
            unset($_SESSION['error_message']);
        }
        ?>