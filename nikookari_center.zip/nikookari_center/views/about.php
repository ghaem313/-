<?php
$title = "درباره ما";
include_once __DIR__ . '/layouts/header.php';
?>
<h1>درباره مرکز نیکوکاری ما</h1>
<p>ما یک سازمان مردم نهاد هستیم که با هدف کمک به نیازمندان فعالیت می‌کنیم.</p>
<?php
include_once __DIR__ . '/layouts/footer.php';
?>