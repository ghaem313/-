<?php
$title = "ثبت‌نام کاربر";
include_once __DIR__ . '/../layouts/header.php';
?>
<form action="<?php echo $_ENV['APP_URL']; ?>/register-submit" method="POST">
    <h2>ثبت‌نام کاربر جدید</h2>
    <label for="first_name">نام:</label>
    <input type="text" id="first_name" name="first_name" required>
    <label for="last_name">نام خانوادگی:</label>
    <input type="text" id="last_name" name="last_name" required>
    <label for="email">ایمیل:</label>
    <input type="email" id="email" name="email" required>
    <label for="password">رمز عبور:</label>
    <input type="password" id="password" name="password" required>
    <label for="confirm_password">تکرار رمز عبور:</label>
    <input type="password" id="confirm_password" name="confirm_password" required>
    <button type="submit">ثبت‌نام</button>
</form>
<?php
include_once __DIR__ . '/../layouts/footer.php';
?>