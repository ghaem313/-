<?php
$title = "ورود مدیر";
include_once __DIR__ . '/../layouts/header.php';
?>
<form action="<?php echo $_ENV['APP_URL']; ?>/admin/login-submit" method="POST">
    <h2>ورود به پنل مدیریت</h2>
    <label for="username">نام کاربری:</label>
    <input type="text" id="username" name="username" required>
    <label for="password">رمز عبور:</label>
    <input type="password" id="password" name="password" required>
    <button type="submit">ورود به پنل</button>
</form>
<?php
include_once __DIR__ . '/../layouts/footer.php';
?>