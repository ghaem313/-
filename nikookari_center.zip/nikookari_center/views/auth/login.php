<?php
$title = "ورود کاربر";
include_once __DIR__ . '/../layouts/header.php';
?>
<form action="<?php echo $_ENV['APP_URL']; ?>/login-submit" method="POST">
    <h2>ورود کاربران</h2>
    <label for="email">ایمیل:</label>
    <input type="email" id="email" name="email" required>
    <label for="password">رمز عبور:</label>
    <input type="password" id="password" name="password" required>
    <button type="submit">ورود</button>
</form>
<?php
include_once __DIR__ . '/../layouts/footer.php';
?>