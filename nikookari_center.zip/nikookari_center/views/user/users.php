<?php
if (!isset($_SESSION['admin_id'])) {
    header("Location: " . $_ENV['APP_URL'] . "/admin/login");
    exit();
}
$title = "مدیریت کاربران";
include_once __DIR__ . '/../layouts/header.php';
?>
<h1>مدیریت کاربران</h1>
<p>لیست کاربران در آینده در این صفحه نمایش داده خواهد شد.</p>
<?php
include_once __DIR__ . '/../layouts/footer.php';
?>