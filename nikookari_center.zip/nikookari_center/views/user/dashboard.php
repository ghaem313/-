<?php
if (!isset($_SESSION['user_id'])) {
    header("Location: " . $_ENV['APP_URL'] . "/login");
    exit();
}
$title = "پروفایل کاربری";
include_once __DIR__ . '/../layouts/header.php';
?>
<h1>خوش آمدید، <?php echo htmlspecialchars($_SESSION['user_first_name'] . ' ' . $_SESSION['user_last_name']); ?>!</h1>
<p>اینجا داشبورد کاربری شماست.</p>
<?php
include_once __DIR__ . '/../layouts/footer.php';
?>