<?php
if (!isset($_SESSION['admin_id'])) {
    header("Location: " . $_ENV['APP_URL'] . "/admin/login");
    exit();
}
$title = "داشبورد مدیریت";
include_once __DIR__ . '/../layouts/header.php';
?>
<h1>خوش آمدید، مدیر <?php echo htmlspecialchars($_SESSION['admin_username']); ?>!</h1>
<p>اینجا داشبورد پنل مدیریت شماست.</p>
<h2>گزینه‌های مدیریت</h2>
<ul>
    <li><a href="<?php echo $_ENV['APP_URL']; ?>/admin/users">مدیریت کاربران</a></li>
</ul>
<?php
include_once __DIR__ . '/../layouts/footer.php';
?>