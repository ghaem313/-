<?php
$title = "صفحه اصلی";
include_once __DIR__ . '/layouts/header.php';
?>
<h1>به سایت مرکز نیکوکاری خوش آمدید</h1>
<p>اینجا محتوای اصلی صفحه خانه قرار می‌گیرد.</p>
<?php
include_once __DIR__ . '/layouts/footer.php';
?>