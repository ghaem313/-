<?php
namespace App\Models;
use PDO;
class User {
    private $conn;
    private $table = 'users';
    public $id;
    public $first_name;
    public $last_name;
    public $email;
    public $phone_number;
    public $password;
    public $profile_picture;
    public $is_active;
    public function __construct($db) {
        $this->conn = $db;
    }
    public function create() {
        $query = "INSERT INTO " . $this->table . " SET first_name=:first_name, last_name=:last_name, email=:email, phone_number=:phone_number, password=:password";
        $stmt = $this->conn->prepare($query);
        $this->first_name = htmlspecialchars(strip_tags($this->first_name));
        $this->last_name = htmlspecialchars(strip_tags($this->last_name));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->phone_number = htmlspecialchars(strip_tags($this->phone_number));
        $this->password = htmlspecialchars(strip_tags($this->password));
        $stmt->bindParam(":first_name", $this->first_name);
        $stmt->bindParam(":last_name", $this->last_name);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":phone_number", $this->phone_number);
        $stmt->bindParam(":password", $this->password);
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
    public function findByEmail() {
        $query = "SELECT id, first_name, last_name, email, password FROM " . $this->table . " WHERE email = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->email);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $this->id = $row['id'];
            $this->first_name = $row['first_name'];
            $this->last_name = $row['last_name'];
            $this->email = $row['email'];
            $this->password = $row['password'];
            return true;
        }
        return false;
    }
}