<?php
namespace App\Models;
use PDO;
class Admin {
    private $conn;
    private $table = 'admins';
    public $id;
    public $username;
    public $password;
    public $email;
    public $role;
    public function __construct($db) {
        $this->conn = $db;
    }
    public function findByUsername() {
        $query = "SELECT id, username, password, role FROM " . $this->table . " WHERE username = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->username);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $this->id = $row['id'];
            $this->username = $row['username'];
            $this->password = $row['password'];
            $this->role = $row['role'];
            return true;
        }
        return false;
    }
}