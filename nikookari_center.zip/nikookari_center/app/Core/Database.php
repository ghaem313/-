<?php
namespace App\Core;
use PDO;
use PDOException;
class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    public $conn;
    public function __construct() {
        if (empty($_ENV['DB_HOST'])) {
            die("???: ??????? ?????? ???? ??? ???? ???. ?? ???? ???? .env ????? ????.");
        }
        $this->host = $_ENV['DB_HOST'];
        $this->db_name = $_ENV['DB_NAME'];
        $this->username = $_ENV['DB_USER'];
        $this->password = $_ENV['DB_PASS'];
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8mb4");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            error_log("Connection error: " . $exception->getMessage());
            die("????????? ????? ?? ????? ?? ?????? ???? ??? ???? ???.");
        }
    }
    public function getConnection() {
        return $this->conn;
    }
}