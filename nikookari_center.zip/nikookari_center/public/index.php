<?php
session_start();
require_once __DIR__ . '/../vendor/autoload.php';
if (file_exists(__DIR__ . '/../.env')) {
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');
    $dotenv->load();
}
use App\Controllers\HomeController;
use App\Controllers\AuthController;
use App\Controllers\AdminController;
$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$base_path = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
if (strpos($request_uri, $base_path) === 0) {
    $request_uri = substr($request_uri, strlen($base_path));
}
$request_uri = '/' . ltrim($request_uri, '/');
switch ($request_uri) {
    case '/':
        (new HomeController())->index();
        break;
    case '/about':
        (new HomeController())->about();
        break;
    case '/register':
        (new AuthController())->showRegisterForm();
        break;
    case '/register-submit':
        (new AuthController())->registerUser();
        break;
    case '/login':
        (new AuthController())->showUserLoginForm();
        break;
    case '/login-submit':
        (new AuthController())->loginUser();
        break;
    case '/logout':
        (new AuthController())->logout();
        break;
    case '/user/dashboard':
        if (isset($_SESSION['user_id'])) {
            $title = "??????? ??????";
            include_once __DIR__ . '/../views/user/dashboard.php';
        } else {
            header("Location: /login");
        }
        break;
    case '/admin/login':
        (new AuthController())->showAdminLoginForm();
        break;
    case '/admin/login-submit':
        (new AuthController())->loginAdmin();
        break;
    case '/admin/dashboard':
        (new AdminController())->dashboard();
        break;
    case '/admin/users':
        (new AdminController())->users();
        break;
    default:
        http_response_code(404);
        echo "<h1>404 - ???? ???? ???</h1>";
        break;
}